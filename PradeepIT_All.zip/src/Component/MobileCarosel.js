import Phone from '../Assets/phone.png';
function MobileCarosel () {
    return(
        <div style={{marginTop:50,backgroundColor:'#EFEFEF'}}>
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active me-2 p-0"></li>
                        <li data-target="#myCarousel" data-slide-to="1" class="me-2 p-0"></li>
                        <li data-target="#myCarousel" data-slide-to="2" class="me-2 p-0"></li>

                    </ol>

                    <div class="carousel-inner" >
                        <div class="item active">
                            <div class="container-fluid ">
                                <div class="row d-flex align-items-center ps-5 Phone" >
                                    <div class="col-md-6 col-sm-6 col-xs-10">
                                        <div style={{ paddingLeft: '70px' }}>
                                        </div>

                                        <img src={Phone} style={{ paddingLeft: '15%' }}></img>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-10" style={{display:'flex',flexDirection:'row',lineHeight:2}}>
                                        <div
                                         style={{ marginRight: 30 }} 
                                         >
                                            <h1 style={{fontSize:80,color:"#000000"}}>01</h1>
                                        </div>
                                        <div style={{borderRight:'1px solid black',height:80,marginRight:50}}></div>
<div>
                                        <h4 style={{ fontSize: 20, color:"#000000",wordSpacing:2}}>M3 WALLET POWERED BY YES BANK</h4>
                                        <h6 style={{ fontSize: 14 }}>MAKE INSTANT MONEY TRANSFER & DIGITAL PAYMENTS</h6><br></br>
                                        <p style={{ fontSize: 14, color: '#5E5E5E' }}>Mobile wallets are no longer just a trend they have become<br></br>
                                            a need of the time. However to relish the benifits of this<br></br>
                                            fast evolving market ,you need to ensure flawless<br></br>
                                            implementation of facts and features
                                        </p>

                                        <button class="btn btn-outline-dark btn-lg">VIEW CASE STUDY</button>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>

                        <div class="item">
                            <div class="container-fluid">
                                <div class="row d-flex align-items-center ps-5" style={{ backgroundColor: '#F6F6F6', height: '70vh' }}>
                                    <div class="col-md-6 col-sm-6 col-xs-10">
                                        <div style={{ paddingLeft: '70px' }} >
                                            <h1 class="ps-3">02</h1>
                                        </div>

                                        <h4 class="ps-4" style={{ fontSize: '20px' }}>CLUSTER INDIA</h4>
                                        <h6 style={{ fontSize: '14px' }}>WEB DESIGN | BRAND STRATEGY</h6>
                                        <p style={{ fontSize: '18px', color: '#5E5E5E' }}>Cluster is platform for eco sysytem which enables a<br></br>
                                            Candiate to Learn ,Experience,Execute and therby<br></br>
                                            Become a smart Software Developer in a short span of time
                                        </p>

                                        <button class="btn btn-outline-dark btn-lg">VIEW CASE STUDY</button>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-10">

                                    </div>

                                </div>
                            </div>

                        </div>

                        <div class="item">
                            <div class="container-fluid">
                                <div class="row d-flex align-items-center ps-5" style={{ backgroundColor: '#F6F6F6', height: '70vh' }}>
                                    <div class="col-md-6 col-sm-6 col-xs-10">
                                        <div style={{ paddingLeft: '70px' }} >
                                            <h1 class="ps-5">03</h1>
                                        </div>

                                        <h4 class="ps-4" style={{ fontSize: '20px' }}>M3 WALLET POWERED BY YES BANK</h4>
                                        <h6 style={{ fontSize: '14px' }}>MAKE INSTANT MONEY TRANSFER & DIGITAL PAYMENTS</h6>
                                        <p style={{ fontSize: '18px', color: '#5E5E5E' }}>Mobile wallets are no longer just a trend they have become<br></br>
                                            a need of the time. However to relish the benifits of this<br></br>
                                            fast evolving market ,you need to ensure flawless<br></br>
                                            implementation of facts and features
                                        </p>

                                        <button class="btn btn-outline-dark btn-lg">VIEW CASE STUDY</button>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-10">

                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>
                </div>
                </div>
    )
}
export default MobileCarosel;