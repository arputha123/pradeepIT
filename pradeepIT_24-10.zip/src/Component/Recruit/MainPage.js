import React from "react";
import Recruit from "./Recruit";
import Candidates from "./Candidates";


function MainPage(){
    return(
        <div >
          <Recruit style={{height:"80vh"}}/>
          <Candidates style={{height:"auto"}}/>

         
 
</div>








       
    )
}
export default MainPage